History
=============
Version 3.6.0.3
  1. Changes for CONTRIB-7764.

Version 3.6.0.2
  1. Improvements.

Version 3.6.0.1
  1. Clone of version 3.6.0.5 of the Grid format.
  2. Port of Grid issue #66: Cannot change image tiles when importing a grid format course.
